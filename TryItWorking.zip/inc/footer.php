</div><!-- end content -->

	<div class="footer">

		<div class="wrapper">

			<ul>		
				<li><a href="https://eng.rizvi.edu.in/">College</a></li>
				<li><a href="https://twitter.com/rizvicoe?lang=en">Twitter</a></li>
			</ul>

			<p>&copy;<?php echo date("Y"); ?> CCL Project</p>

		</div>
	
	</div>

</body>
</html>